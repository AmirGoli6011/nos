<!DOCTYPE html>
<html lang="fa" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Nerds Of School</title>







        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/favicon.ico')); ?>"/>
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo e(asset('css/bootstrap.rtl.min.css')); ?>" rel="stylesheet"/>
        <?php echo \Livewire\Livewire::styles(); ?>

        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    </head>
    <body>




        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo e($slot); ?>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Core theme JS-->
        <?php echo \Livewire\Livewire::scripts(); ?>

        <script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
    </body>
</html>
<?php /**PATH F:\Users\Desktop\nos\resources\views/layouts/guest.blade.php ENDPATH**/ ?>