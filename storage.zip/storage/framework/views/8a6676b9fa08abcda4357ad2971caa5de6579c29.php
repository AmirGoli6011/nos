
<?php $__env->startSection('header'); ?>
    <!-- Page header with logo and tagline-->
    <header class="py-5 bg-light border-bottom mb-4">
        <div class="container">
            <div class="text-center my-5">
                <h1 class="fw-bolder">به پنل ادمین خوش اومدی</h1>
                <p class="lead mb-0">به بخش کامنت ها خوش اومدی</p>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <div class="row">
                    <table class="table text-center">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Comment</th>
                            <th>Post</th>
                        </tr>
                        </thead>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                            <tr>
                                <td><?php echo e($comment->id); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.user',$comment->user->username)); ?>">
                                        <p>
                                            <?php echo e($comment->user->name); ?>

                                        </p>
                                        <img class="img-fluid rounded" style="width: 70px"
                                             src="<?php echo e(asset($comment->user->avatar)); ?>" alt="">
                                    </a>
                                    <form action="<?php echo e(route('user.destroy',$comment->user->username)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">حذف</button>
                                    </form>
                                </td>
                                <td>
                                    <?php echo $comment->comment; ?>

                                    <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">حذف</button>
                                    </form>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('post.show',$comment->post->slug)); ?>">
                                        <p>
                                            <?php echo e($comment->post->title); ?>

                                        </p>
                                        <img class="img-fluid rounded" style="width: 70px"
                                             src="<?php echo e(asset($comment->post->image)); ?>" alt="">
                                    </a>
                                    <form action="<?php echo e(route('post.destroy',$comment->post->slug)); ?>" method="post">
                                        <a class="btn btn-success"
                                           href="<?php echo e(route('post.edit',$comment->post->slug)); ?>">ویرایش</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">حذف</button>
                                    </form>
                                </td>
                            </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <!-- Pagination-->
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layouts.sidebar', [])->html();
} elseif ($_instance->childHasBeenRendered('k9Gsuvs')) {
    $componentId = $_instance->getRenderedChildComponentId('k9Gsuvs');
    $componentTag = $_instance->getRenderedChildComponentTagName('k9Gsuvs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('k9Gsuvs');
} else {
    $response = \Livewire\Livewire::mount('layouts.sidebar', []);
    $html = $response->html();
    $_instance->logRenderedChild('k9Gsuvs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Users\Desktop\nos\resources\views/admin/comments.blade.php ENDPATH**/ ?>