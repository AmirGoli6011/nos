    <div>
    <h1 wire:click="name"><?php echo e($name); ?></h1>
    </div><?php /**PATH F:\Users\Desktop\nos\storage\framework\views/d650a302eaece264a8f196afe46e6ae508a6980e.blade.php ENDPATH**/ ?>