<div>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <!-- Blog post-->
                            <div class="card mb-4">
                                <a href="<?php echo e(route('post.show',$post->slug)); ?>">
                                    <img class="card-img-top"
                                         src="<?php echo e(asset($post->image)); ?>"
                                         alt="<?php echo e($post->title); ?>"/>
                                </a>
                                <div class="card-body">
                                    <div class="small text-muted">
                                        نوشته شده در <?php echo e(verta($post->created_at)->formatJalaliDatetime()); ?>

                                    </div>
                                    <a href="<?php echo e(route('post.show',$post->slug)); ?>">
                                        <h2 class="card-title h4"><?php echo e($post->title); ?></h2>
                                    </a>
                                    <p>
                                        <?php echo Str::limit(strip_tags($post->body)); ?>

                                    </p>
                                    <p>
                                        <?php if($post->favoriters()->count() === 1): ?>
                                            <?php echo e($post->favoriters()->count()); ?> نفر اضافه کرده به علاقه مندی هاش
                                        <?php elseif($post->favoriters()->count() === 0): ?>
                                            هیچکس اضافه نکرده به علاقه مندی هاش
                                        <?php else: ?>
                                            <?php echo e($post->favoriters()->count()); ?> نفر اضافه کردن به علاقه مندی هاشون
                                        <?php endif; ?>
                                    </p>
                                    <a class="btn btn-success"
                                       href="<?php echo e(route('post.edit',$post->slug)); ?>">
                                        ویرایش</a>
                                    <button class="btn btn-danger" wire:click="delete(<?php echo e($post->id); ?>)">حذف</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Pagination-->

            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layouts.sidebar', [])->html();
} elseif ($_instance->childHasBeenRendered('l951348114-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l951348114-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l951348114-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l951348114-0');
} else {
    $response = \Livewire\Livewire::mount('layouts.sidebar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l951348114-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/post/index.blade.php ENDPATH**/ ?>