<!-- Footer-->
<footer class="py-4 bg-dark">
    <div class="container">
        <p class="m-0 text-center text-white">
            تمامی حقوق وب سایت متعلق به &copy; Goli است
        </p>
    </div>
</footer><?php /**PATH F:\Users\Desktop\nos\resources\views/layouts/footer.blade.php ENDPATH**/ ?>