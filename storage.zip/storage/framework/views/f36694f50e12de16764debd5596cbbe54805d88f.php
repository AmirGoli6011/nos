<div class="col-lg-6">
    <!-- Blog post-->
    <div class="card mb-4">
        <a href="<?php echo e(route('post.show',$post->slug)); ?>">
            <img class="card-img-top"
                 src="<?php echo e(asset($post->image)); ?>"
                 alt="<?php echo e($post->title); ?>"/>
        </a>
        <div class="card-body">
            <div class="small text-muted">
                نوشته شده در <?php echo e(verta($post->created_at)->formatJalaliDate()); ?>

                توسط
                <a class="small text-muted"
                   href="<?php echo e(route('profile',$post->user->username)); ?>"><?php echo e($post->user->name); ?></a>
                <a href="<?php echo e(route('profile',$post->user->username)); ?>">
                    <img class="img-fluid" src="<?php echo e(asset($post->user->avatar)); ?>"
                         alt="<?php echo e($post->user->name); ?>"
                         style="width: 60px">
                </a>
                <?php if(auth()->id() !== $post->user->id): ?>
                    <?php if(auth()->user()->isFollowing($post->user)): ?>
                        <input type="button" class="btn btn-sm"
                               wire:click="follow()"
                               value="دنبال نکردن">
                    <?php else: ?>
                        <input type="button" class="btn btn-sm"
                               wire:click="follow()"
                               value="دنبال کردن">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('post.show',$post->slug)); ?>">
                <h2 class="card-title h4"><?php echo e($post->title); ?></h2>
            </a>
            <a href="<?php echo e(route('post.show',$post->slug)); ?>">
                <p class="link-body-emphasis">
                    <?php echo Str::limit(strip_tags($post->body)); ?>

                </p>
            </a>
            <?php if(auth()->id() !== $post->user->id): ?>
                <?php if(auth()->user()->hasFavorited($post)): ?>
                    <img src="<?php echo e(asset('css/bootstrap-icons/heart-fill.svg')); ?>" alt="like"
                         wire:click="like(<?php echo e($post->id); ?>)"
                         width="16" height="16">
                <?php else: ?>
                    <img src="<?php echo e(asset('css/bootstrap-icons/heart.svg')); ?>" alt="like"
                         wire:click="like(<?php echo e($post->id); ?>)"
                         width="16" height="16">
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/post.blade.php ENDPATH**/ ?>