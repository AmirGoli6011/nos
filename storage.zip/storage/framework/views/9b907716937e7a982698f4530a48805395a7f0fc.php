
<?php $__env->startSection('header'); ?>
    <!-- Page header with logo and tagline-->
    <header class="py-5 bg-light border-bottom mb-4">
        <div class="container">
            <div class="text-center my-5">
                <h1 class="fw-bolder">به پست هایی که ساختی خوش اومدی!</h1>
                <p class="lead mb-0">اینجا میتونی پست هایی که ساختی رو ببینی و ویرایش یا حذف کنی</p>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post.index', [])->html();
} elseif ($_instance->childHasBeenRendered('1chOlEG')) {
    $componentId = $_instance->getRenderedChildComponentId('1chOlEG');
    $componentTag = $_instance->getRenderedChildComponentTagName('1chOlEG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1chOlEG');
} else {
    $response = \Livewire\Livewire::mount('post.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('1chOlEG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Users\Desktop\nos\resources\views/post/index.blade.php ENDPATH**/ ?>