<!-- Page content-->
<div class="container">
    <div class="row">
        <!-- Blog entries-->
        <div class="col-lg-6">
            <div class="card text-center">
                <div class="card-header">
                    <img src="<?php echo e(asset($user->avatar)); ?>" alt="<?php echo e($user->name); ?>" width="200px">
                </div>
                <div class="card-body">
                    <h3><?php echo e($user->name); ?></h3>
                    <?php if(auth()->user()->id !== $user->id): ?>
                        <?php if(auth()->user()->isFollowing($user)): ?>
                            <button wire:click="follow(<?php echo e($user->id); ?>)" class="btn">
                                دنبال نکردن
                            </button>
                        <?php else: ?>
                            <button wire:click="follow(<?php echo e($user->id); ?>)" class="btn">
                                دنبال کردن
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="row text-center">
                <div class="col-lg-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>دنبال کننده ها: <?php echo e($user->followers()->count()); ?></h5>
                        </div>
                        <div class="card-body">
                            <?php $__currentLoopData = $user->followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('profile',$follower->username)); ?>">
                                    <img src="<?php echo e(asset($follower->avatar)); ?>" alt="<?php echo e($follower->name); ?>"
                                         style="width: 100px;">
                                    <h5><?php echo e($follower->name); ?></h5>
                                </a>
                                <?php if(auth()->user()->id !== $follower->id): ?>
                                    <?php if(auth()->user()->isFollowing($follower)): ?>
                                        <button wire:click="follow(<?php echo e($follower->id); ?>)" class="btn">
                                            دنبال نکردن
                                        </button>
                                    <?php else: ?>
                                        <button wire:click="follow(<?php echo e($follower->id); ?>)" class="btn">
                                            دنبال کردن
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5>دنبال شونده ها: <?php echo e($user->followings()->count()); ?></h5>
                        </div>
                        <div class="card-body">
                            <?php $__currentLoopData = $user->followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('profile',$followings->username)); ?>">
                                    <img src="<?php echo e(asset($followings->avatar)); ?>" alt="<?php echo e($followings->name); ?>"
                                         style="width: 100px;">
                                    <h5><?php echo e($followings->name); ?></h5>
                                </a>
                                <?php if(auth()->user()->id !== $followings->id): ?>
                                    <?php if(auth()->user()->isFollowing($followings)): ?>
                                        <button wire:click="follow(<?php echo e($followings->id); ?>)" class="btn">
                                            دنبال نکردن
                                        </button>
                                    <?php else: ?>
                                        <button wire:click="follow(<?php echo e($followings->id); ?>)" class="btn">
                                            دنبال کردن
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/profile.blade.php ENDPATH**/ ?>