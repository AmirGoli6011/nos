<!-- Responsive navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            Nerds Of School
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span
                    class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->id === 1): ?>
                        <li class="nav-item">
                            <a class="nav-link"
                               href="<?php echo e(route('admin.posts')); ?>">
                                پست ها
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               href="<?php echo e(route('admin.users')); ?>">
                                یوزر ها
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               href="<?php echo e(route('admin.comments')); ?>">
                                کامنت ها
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"
                               href="<?php echo e(route('tag.index')); ?>">
                                تگ ها
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('tag.create')); ?>">
                                ساخت تگ
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('post.create')); ?>">
                            ساخت پست
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="<?php echo e(route('favorite.index')); ?>">
                            علاقه مندی ها
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="<?php echo e(route('post.index')); ?>">
                            پست ها
                        </a>
                    </li>
                    <div class="dropdown">
                        <a href="" class="d-block link-body-emphasis text-decoration-none dropdown-toggle"
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <img class="img-fluid rounded"
                                 style="width: 70px"
                                 src="<?php echo e(asset(auth()->user()->avatar)); ?>" alt="<?php echo e(auth()->user()->name); ?>">
                        </a>
                        <ul class="dropdown-menu text-center">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">
                                    داشبورد
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('profile',auth()->user()->username)); ?>">
                                    پروفایل
                                </a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <a class="dropdown-item" href="">
                                    <form action="<?php echo e(route('logout')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn" type="submit">
                                            خروج
                                        </button>
                                    </form>
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">ثبت نام</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">ورود</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php echo $__env->yieldContent('header'); ?><?php /**PATH F:\Users\Desktop\nos\resources\views/layouts/header.blade.php ENDPATH**/ ?>