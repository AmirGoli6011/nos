    <div>
    <h1>sad</h1>
    </div><?php /**PATH F:\Users\Desktop\nos\storage\framework\views/b7b6f3a1d1b8a01f36491f96233c9865f5d1e7b4.blade.php ENDPATH**/ ?>