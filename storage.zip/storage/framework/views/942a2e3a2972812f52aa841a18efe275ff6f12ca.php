
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post.show', ['post' => $post])->html();
} elseif ($_instance->childHasBeenRendered('uqGv8kU')) {
    $componentId = $_instance->getRenderedChildComponentId('uqGv8kU');
    $componentTag = $_instance->getRenderedChildComponentTagName('uqGv8kU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uqGv8kU');
} else {
    $response = \Livewire\Livewire::mount('post.show', ['post' => $post]);
    $html = $response->html();
    $_instance->logRenderedChild('uqGv8kU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Users\Desktop\nos\resources\views/post/show.blade.php ENDPATH**/ ?>