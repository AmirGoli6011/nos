<div class="col-lg-4">
    <!-- Side widgets-->
    <div class="relative p-2">
        <!-- Search widget-->
        <div class="card mb-4">
            <div class="card-header">جستجو</div>
            <div class="card-body">
                <div class="input-group">
                    <input wire:model.debounce.1s="search" class="form-control" type="text" name="search"
                           placeholder="عبارت جستجو را وارد کنید..."
                           aria-label="Enter search term..." aria-describedby="button-search"/>
                </div>
            </div>
        </div>
        <div wire:loading class="w-1/3 bg-white rounded-lg shadow">
            <ul class="divide-y-2 divide-gray-100">
                <li class="p-2 hover:bg-blue-600 hover:text-blue-200">
                    درحال جسجتو...
                </li>
            </ul>
        </div>
        <?php if(!empty($search)): ?>
            <div class="w-1/3 bg-white rounded-lg shadow">
                <?php if(!empty($posts)): ?>
                    <ul class="divide-y-2 divide-gray-100">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="p-2 hover:bg-blue-600 hover:text-blue-200">
                                <a href="<?php echo e(route('post.show',$post->slug)); ?>" class="padding-top-5 list-item">
                                    <?php echo e($post->title); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <div class="list-item">No results!</div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <!-- Categories widget-->
        <div class="card mb-4">
            <div class="card-header">تگ ها</div>
            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = App\Models\Tag::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6">
                            <ul class="list-unstyled mb-0">
                                <li><a href="<?php echo e(route('tag.show',$tag->name)); ?>"><?php echo e($tag->name); ?></a></li>
                            </ul>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/sidebar.blade.php ENDPATH**/ ?>