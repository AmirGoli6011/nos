    <div>
    <h1><?php echo e($name); ?></h1>
    </div><?php /**PATH F:\Users\Desktop\nos\storage\framework\views/495149776db2c1be4b3215595c3c716f7e576322.blade.php ENDPATH**/ ?>