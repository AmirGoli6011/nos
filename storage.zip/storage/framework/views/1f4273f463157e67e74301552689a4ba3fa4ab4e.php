    <div>
                                    <img src="<?php echo e(asset('css/bootstrap-icons/heart.svg')); ?>" alt="like"
                                         id="favorite" width="16" height="16">
    </div><?php /**PATH F:\Users\Desktop\nos\storage\framework\views/869559816c7b132c603681a76a28ddb47852afb9.blade.php ENDPATH**/ ?>