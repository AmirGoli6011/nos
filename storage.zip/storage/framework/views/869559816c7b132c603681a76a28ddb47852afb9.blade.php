    <div>
                                    <img src="{{ asset('css/bootstrap-icons/heart.svg') }}" alt="like"
                                         id="favorite" width="16" height="16">
    </div>