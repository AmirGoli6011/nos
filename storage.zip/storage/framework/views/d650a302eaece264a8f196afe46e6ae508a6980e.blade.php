    <div>
    <h1 wire:click="name">{{ $name }}</h1>
    </div>