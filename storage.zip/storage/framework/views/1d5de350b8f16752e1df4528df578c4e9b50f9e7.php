    				<div>
                                    <img src="<?php echo e(asset('css/bootstrap-icons/heart-fill.svg')); ?>" alt="like"
                                         wire:click="like(<?php echo e(auth()->user()->id); ?>,<?php echo e($post->id); ?>)"
                                         id="favorite<?php echo e($post->id); ?>" width="16" height="16">
    				</div><?php /**PATH F:\Users\Desktop\nos\storage\framework\views/9fa5fbb3646e34cd7f9ef1fbe234c5386d29a106.blade.php ENDPATH**/ ?>