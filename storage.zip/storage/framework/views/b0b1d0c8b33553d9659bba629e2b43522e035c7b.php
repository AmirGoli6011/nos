<div>
    <!-- Page content-->
    <div class="container mt-5">
        <div class="row">
            <div class="col-lg-8">
                <!-- Post content-->
                <article>
                    <!-- Post header-->
                    <header class="mb-4">
                        <!-- Post title-->
                        <h1 class="fw-bolder mb-1" id="title"><?php echo e($post->title); ?></h1>
                        <!-- Post meta content-->
                        <div class="text-muted fst-italic mb-2">
                            نوشته شده در<?php echo e(verta($post->created_at)->format('%d %B %y h:i')); ?>

                            <br>
                            توسط <?php echo e($user->name); ?>

                        </div>
                        <!-- Post categories-->
                        <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="badge bg-secondary text-decoration-none link-light"
                               href="<?php echo e(route('tag.show',$tag->name)); ?>"><?php echo e($tag->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </header>
                    <!-- Preview image figure-->
                    <figure class="mb-4"><img class="img-fluid rounded"
                                              src="<?php echo e(asset($post->image)); ?>" alt="<?php echo e($post->title); ?>"/>
                    </figure>
                    <!-- Post content-->
                    <section class="mb-5">
                        <?php echo $post->body; ?>

                    </section>
                </article>
                <!-- Comments section-->
                <section class="mb-5">
                    <div class="card bg-light">
                        <div class="card-body">
                            <!-- Comment form-->
                            <textarea id="comment" wire:model="comment" class="form-control"
                                      rows="3" placeholder="به بحث بپیوندید و نظر بدهید!"></textarea>
                            <button class="btn btn-success" wire:click="comment">ارسال</button>
                            
                            <!-- Single comment-->
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p>
                                    <?php echo e($comment->created_at->diffForHumans()); ?>

                                </p>
                                <div class="d-flex">
                                    <div class="flex-shrink-0">
                                        <img class="img-fluid rounded"
                                             style="width: 70px"
                                             src="<?php echo e(asset($comment->user->avatar)); ?>"
                                             alt="<?php echo e($comment->user->name); ?>"/>
                                    </div>
                                    <div class="ms-3">
                                        <div class="fw-bold"><?php echo e($comment->user->name); ?></div>
                                        <?php echo e($comment->comment); ?>

                                        
                                    </div>
                                    <?php if(auth()->guard()->check()): ?>
                                        <div class="btn btn-group">
                                            <?php if($post->user->id === auth()->user()->id or auth()->user()->id === 1 or auth()->user()->id === $comment->user->id): ?>
                                                <button wire:click="delete(<?php echo e($comment->id); ?>)" class="btn btn-danger">
                                                    حذف
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </section>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layouts.sidebar', [])->html();
} elseif ($_instance->childHasBeenRendered('l3736590270-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3736590270-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3736590270-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3736590270-0');
} else {
    $response = \Livewire\Livewire::mount('layouts.sidebar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3736590270-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/post/show.blade.php ENDPATH**/ ?>