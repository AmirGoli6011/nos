    <div>
                                    <img src="<?php echo e(asset('css/bootstrap-icons/heart.svg')); ?>" alt="like"
                                         wire:click="like(<?php echo e(auth()->user()->id); ?>,<?php echo e($post->id); ?>)"
                                         id="favorite<?php echo e($post->id); ?>" width="16" height="16">
    </div><?php /**PATH F:\Users\Desktop\nos\storage\framework\views/72b724df274478289f82f53f3263d09038d38c9e.blade.php ENDPATH**/ ?>