<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <title>Nerds Of School</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/favicon.ico')); ?>"/>
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('css/bootstrap.rtl.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(asset('js/tinymce/tinymce.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Core theme JS-->
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/swal.min.js')); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<script>
    window.livewire.on('successAlert', function(message){
        Swal.fire({
            position: "center",
            icon: "success",
            title: message,
            showConfirmButton: false,
            timer: 1500
        });
    })
</script>
</body>
</html><?php /**PATH F:\Users\Desktop\nos\resources\views/layouts/app.blade.php ENDPATH**/ ?>