    <div>
        <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->hasFavorited($post)): ?>
                                    <img src="<?php echo e(asset('css/bootstrap-icons/heart-fill.svg')); ?>" alt="like"
                                         wire:click="like(<?php echo e(auth()->user()->id); ?>,<?php echo e($post->id); ?>)"
                                         id="favorite<?php echo e($post->id); ?>" width="16" height="16">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('css/bootstrap-icons/heart.svg')); ?>" alt="like"
                                         wire:click="like(<?php echo e(auth()->user()->id); ?>,<?php echo e($post->id); ?>)"
                                         id="favorite<?php echo e($post->id); ?>" width="16" height="16">
                                <?php endif; ?>
                            <?php endif; ?>
    </div><?php /**PATH F:\Users\Desktop\nos\storage\framework\views/2b2df4a4ce6d57f2e03f2b4b318a0e76c3b17f8f.blade.php ENDPATH**/ ?>