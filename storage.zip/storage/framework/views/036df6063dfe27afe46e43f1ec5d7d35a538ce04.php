<!-- Side widgets-->
<div class="col-lg-4">
    <!-- Search widget-->
    <div class="card mb-4">
        <div class="card-header">جستجو</div>
        <div class="card-body">

                <div class="input-group">
                    <input class="form-control" type="text" name="search" placeholder="عبارت جستجو را وارد کنید..."
                           aria-label="Enter search term..." aria-describedby="button-search"/>
                    <button class="btn btn-primary" id="button-search" type="submit">برو!</button>
                </div>

        </div>
    </div>
    <!-- Categories widget-->
    <div class="card mb-4">
        <div class="card-header">تگ ها</div>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = App\Models\Tag::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6">
                        <ul class="list-unstyled mb-0">
                            <li><a href="<?php echo e(route('tag.show',$tag->name)); ?>"><?php echo e($tag->name); ?></a></li>
                        </ul>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\Users\Desktop\nos\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>