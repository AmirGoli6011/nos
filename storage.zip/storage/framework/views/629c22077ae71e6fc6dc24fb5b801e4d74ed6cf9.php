<div class="col-lg-6">
    <!-- Blog post-->
    <div class="card mb-4">
        <a href="<?php echo e(route('post.show',$post->slug)); ?>">
            <img class="card-img-top"
                 src="<?php echo e(asset($post->image)); ?>"
                 alt="<?php echo e($post->title); ?>"/>
        </a>
        <div class="card-body">
            <div class="small text-muted">
                نوشته شده در <?php echo e(verta($post->created_at)->formatJalaliDatetime()); ?>

            </div>
            <a href="<?php echo e(route('post.show',$post->slug)); ?>">
                <h2 class="card-title h4"><?php echo e($post->title); ?></h2>
            </a>
            <p>
                <?php echo Str::limit(strip_tags($post->body)); ?>

            </p>
            <p>
                <?php if($post->favoriters()->count() > 1): ?>
                    <?php echo e($post->favoriters()->count()); ?> نفر افزوده به علاقه مندی ها
                <?php elseif($post->favoriters()->count() === 1): ?>
                    <?php echo e($post->favoriters()->count()); ?> نفر افزوده به علاقه مندی ها
                <?php else: ?>
                    هیچکس نیافزوده به علاقه مندی ها
                <?php endif; ?>
            </p>
            <a class="btn btn-success" href="<?php echo e(route('post.edit',$post->slug)); ?>">ویرایش</a>
            <button wire:click="delete()" class="btn btn-danger">حذف</button>
        </div>
    </div>
</div><?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/index-post.blade.php ENDPATH**/ ?>