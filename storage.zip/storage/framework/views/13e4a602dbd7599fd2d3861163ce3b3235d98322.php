
<?php $__env->startSection('header'); ?>
    <!-- Page header with logo and tagline-->
    <header class="py-5 bg-light border-bottom mb-4">
        <div class="container">
            <div class="text-center my-5">
                <h1 class="fw-bolder">به پنل ادمین خوش اومدی</h1>
                <p class="lead mb-0">به بخش کامنت ها خوش اومدی</p>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <div class="row">
                    <table class="table text-center">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tags</th>
                        </tr>
                        </thead>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                            <tr>
                                <td><?php echo e($tag->id); ?></td>
                                <td>
                                    <p>
                                        <?php echo e($tag->name); ?>

                                    </p>
                                    <form action="<?php echo e(route('tag.destroy',$tag->name)); ?>" method="post">
                                        <a class="btn btn-success"
                                           href="<?php echo e(route('tag.edit',$tag->name)); ?>">ویرایش</a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">حذف</button>
                                    </form>
                                </td>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <!-- Pagination-->
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layouts.sidebar', [])->html();
} elseif ($_instance->childHasBeenRendered('U9MuajE')) {
    $componentId = $_instance->getRenderedChildComponentId('U9MuajE');
    $componentTag = $_instance->getRenderedChildComponentTagName('U9MuajE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('U9MuajE');
} else {
    $response = \Livewire\Livewire::mount('layouts.sidebar', []);
    $html = $response->html();
    $_instance->logRenderedChild('U9MuajE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Users\Desktop\nos\resources\views/admin/tags.blade.php ENDPATH**/ ?>