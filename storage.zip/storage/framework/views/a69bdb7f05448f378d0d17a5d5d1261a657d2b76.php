

<?php $__env->startSection('content'); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('auth.register', [])->html();
} elseif ($_instance->childHasBeenRendered('aBTMfU2')) {
    $componentId = $_instance->getRenderedChildComponentId('aBTMfU2');
    $componentTag = $_instance->getRenderedChildComponentTagName('aBTMfU2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aBTMfU2');
} else {
    $response = \Livewire\Livewire::mount('auth.register', []);
    $html = $response->html();
    $_instance->logRenderedChild('aBTMfU2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Users\Desktop\nos\resources\views/auth/register.blade.php ENDPATH**/ ?>