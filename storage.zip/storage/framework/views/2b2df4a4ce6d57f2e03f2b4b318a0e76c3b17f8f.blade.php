    <div>
        @auth()
                                @if(auth()->user()->hasFavorited($post))
                                    <img src="{{ asset('css/bootstrap-icons/heart-fill.svg') }}" alt="like"
                                         wire:click="like({{ auth()->user()->id }},{{ $post->id }})"
                                         id="favorite{{ $post->id }}" width="16" height="16">
                                @else
                                    <img src="{{ asset('css/bootstrap-icons/heart.svg') }}" alt="like"
                                         wire:click="like({{ auth()->user()->id }},{{ $post->id }})"
                                         id="favorite{{ $post->id }}" width="16" height="16">
                                @endif
                            @endauth
    </div>