<div>
    <?php if(auth()->user()->id !== $user->id): ?>
        <?php if(auth()->user()->isFollowing($user)): ?>
            <button wire:click="follow" class="btn">
                دنبال نکردن
            </button>
        <?php else: ?>
            <button wire:click="follow" class="btn">
                دنبال کردن
            </button>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/follow.blade.php ENDPATH**/ ?>