<div>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-6">
                <div class="card text-center">
                    <div class="card-header">
                        <img src="<?php echo e(asset($user->avatar)); ?>" alt="<?php echo e($user->name); ?>" width="200px">
                    </div>
                    <!-- User Profile-->
                    <div class="card-body">
                        <h3><?php echo e($user->name); ?></h3>
                        <?php if(auth()->user()->id !== $user->id): ?>
                            <?php if(auth()->user()->isFollowing($user)): ?>
                                <button class="btn" wire:click="unfollow(<?php echo e($user->id); ?>)">
                                    دنبال نکردن
                                </button>
                            <?php else: ?>
                                <button class="btn" wire:click="follow(<?php echo e($user->id); ?>)">
                                    دنبال کردن
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row text-center">
                    <div class="col-lg-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>دنبال کننده ها: <?php echo e($user->followers()->count()); ?></h5>
                            </div>
                            <div class="card-body">
                                <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('profile',$follower->username)); ?>">
                                        <img src="<?php echo e(asset($follower->avatar)); ?>" alt="<?php echo e($follower->name); ?>"
                                             style="width: 100px;">
                                        <h5><?php echo e($follower->name); ?></h5>
                                    </a>
                                    <?php if(auth()->user()->id !== $follower->id): ?>
                                        <?php if(auth()->user()->isFollowing($follower)): ?>
                                            <button class="btn"
                                                    wire:click="unfollow(<?php echo e($follower->id); ?>)">
                                                دنبال نکردن
                                            </button>
                                        <?php else: ?>
                                            <button class="btn"
                                                    wire:click="follow(<?php echo e($follower->id); ?>)">
                                                دنبال کردن
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5>دنبال شونده ها: <?php echo e($user->followings()->count()); ?></h5>
                            </div>
                            <div class="card-body">
                                <?php $__currentLoopData = $followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $following): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('profile',$following->username)); ?>">
                                        <img src="<?php echo e(asset($following->avatar)); ?>" alt="<?php echo e($following->name); ?>"
                                             style="width: 100px;">
                                        <h5><?php echo e($following->name); ?></h5>
                                    </a>
                                    <?php if(auth()->user()->id !== $following->id): ?>
                                        <?php if(auth()->user()->isFollowing($following)): ?>
                                            <button class="btn"
                                                    wire:click="unfollow(<?php echo e($following->id); ?>)">
                                                دنبال نکردن
                                            </button>
                                        <?php else: ?>
                                            <button class="btn"
                                                    wire:click="follow(<?php echo e($following->id); ?>)">
                                                دنبال کردن
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/user/profile.blade.php ENDPATH**/ ?>