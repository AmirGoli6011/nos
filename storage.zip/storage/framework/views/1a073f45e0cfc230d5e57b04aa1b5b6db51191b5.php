<div>
    <?php $__env->startSection('header'); ?>
        <!-- Page header with logo and tagline-->
        <header class="py-5 bg-light border-bottom mb-4">
            <div class="container">
                <div class="text-center my-5">
                    <h1 class="fw-bolder">به لیست علاقه مندی ها خوش اومدی!</h1>
                    <p class="lead mb-0">اینجا میتونی پست هایی که به علاقه مندی اضافه کردی رو ببینی</p>
                </div>
            </div>
        </header>
    <?php $__env->stopSection(); ?>
    <!-- Page content-->
    <div class="container">
        <div class="row">
            <!-- Blog entries-->
            <div class="col-lg-8">
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <!-- Blog post-->
                            <div class="card mb-4">
                                <a href="<?php echo e(route('post.show',$post->slug)); ?>"><img class="card-img-top"
                                                                                    src="<?php echo e(asset($post->image)); ?>"
                                                                                    alt="<?php echo e($post->title); ?>"/></a>
                                <div class="card-body">
                                    <div class="small text-muted">
                                        نوشته شده در <?php echo e(verta($post->created_at)->formatJalaliDate()); ?>

                                        توسط <?php echo e($post->user->name); ?>

                                    </div>
                                    <a href="<?php echo e(route('post.show',$post->slug)); ?>">
                                        <h2 class="card-title h4"><?php echo e($post->title); ?></h2>
                                    </a>
                                    <p>
                                        <?php echo Str::limit(strip_tags($post->body)); ?>

                                    </p>
                                    <img src="<?php echo e(asset('css/bootstrap-icons/heart-fill.svg')); ?>" alt="like"
                                         wire:click="like(<?php echo e($post->id); ?>)"
                                         id="favorite<?php echo e($post->id); ?>" width="16" height="16">
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Pagination-->
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layouts.sidebar', [])->html();
} elseif ($_instance->childHasBeenRendered('l2170723485-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2170723485-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2170723485-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2170723485-0');
} else {
    $response = \Livewire\Livewire::mount('layouts.sidebar', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2170723485-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/favorite/index.blade.php ENDPATH**/ ?>