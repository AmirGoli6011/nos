<div>
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->hasFavorited($post)): ?>
            <h5><?php echo e($name); ?></h5>
            <input type="text" wire:model="name">
            <img src="<?php echo e(asset('css/bootstrap-icons/heart.svg')); ?>" alt="like"
                 wire:click="like(<?php echo e(auth()->user()->id); ?>,<?php echo e($post->id); ?>)"
                 id="favorite" width="16" height="16">
        <?php else: ?>
            <img src="<?php echo e(asset('css/bootstrap-icons/heart-fill.svg')); ?>" alt="like"
                 wire:click="like(<?php echo e(auth()->user()->id); ?>,<?php echo e($post->id); ?>)"
                 id="favorite" width="16" height="16">
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH F:\Users\Desktop\nos\resources\views/livewire/like.blade.php ENDPATH**/ ?>