
<?php $__env->startSection('header'); ?>
    <!-- Page header with logo and tagline-->
    <header class="py-5 bg-light border-bottom mb-4">
        <div class="container">
            <div class="text-center my-5">
                <h1 class="fw-bolder">به سایت Nerds Of School خوش اومدی!</h1>
                <p class="lead mb-0">بهترین جا برای تلف کرن وقت</p>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home', [])->html();
} elseif ($_instance->childHasBeenRendered('5kBOJHz')) {
    $componentId = $_instance->getRenderedChildComponentId('5kBOJHz');
    $componentTag = $_instance->getRenderedChildComponentTagName('5kBOJHz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5kBOJHz');
} else {
    $response = \Livewire\Livewire::mount('home', []);
    $html = $response->html();
    $_instance->logRenderedChild('5kBOJHz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Users\Desktop\nos\resources\views/home.blade.php ENDPATH**/ ?>